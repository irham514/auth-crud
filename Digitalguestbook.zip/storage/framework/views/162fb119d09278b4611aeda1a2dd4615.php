<?php $__env->startSection('content'); ?>

<div class="container">
    <h1>Daftar Tamu</h1><br>
    <a href="<?php echo e(route('tamu.index')); ?>" class="btn btn-primary">Home</a>
    <a href="<?php echo e(route('tamu.create')); ?>" class="btn btn-primary">Tambahkan Tamu</a>
    <?php if(session('success')): ?>
        <div class="alert alert-success"><?php echo e(session('success')); ?></div>
    <?php endif; ?>

    <table class="table table-striped" border="1">
        <thead>
            <tr>
                <th>ID</th>
                <th>Nama</th>
                <th>Alamat<th>
                <th>Nomor Telepon</th>
                <th>Action</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $tamus; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tamu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($tamu ->id); ?></td>
                    <td><?php echo e($tamu ->nama); ?></td>
                    <td><?php echo e($tamu ->alamat); ?></td>
                    <td><?php echo e($tamu ->nomor_telepon); ?></td>
                    <td>
                        <a href="<?php echo e(route('tamu.edit', $tamu->id)); ?>" class="btn btn-primary">Edit</a>
                        <form action="<?php echo e(route('tamu.destroy', $tamu->id)); ?>" method="POST">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('DELETE'); ?>
                            <button type="submit" class="btn btn-danger">Hapus</button>
                        </form>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Bootcamp\Digitalguestbook\resources\views/tamu/index.blade.php ENDPATH**/ ?>