<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
    <?php echo app('Illuminate\Foundation\Vite')(['resources/sass/app.scss','resources/js/app.js']); ?>
</head>
<body>
    <div class="container">
        <h1>Daftar Tamu</h1>
    
        <form action="<?php echo e(route('tamu.update', $tamus->id)); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>
        Nama: <input type="text" name="nama" required><br>
        Alamat: <input type="text" name="alamat" required><br>
        No. Telepon: <input type="text" name="nomor_telepon" required>
        <input type="submit" value="submit">
        </form>
    </div>    
</body>
</html>
<?php /**PATH C:\Bootcamp\Digitalguestbook\resources\views/tamu/edit.blade.php ENDPATH**/ ?>